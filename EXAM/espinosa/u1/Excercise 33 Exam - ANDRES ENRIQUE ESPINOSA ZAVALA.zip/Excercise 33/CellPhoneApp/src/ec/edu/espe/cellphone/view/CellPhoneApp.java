package ec.edu.espe.cellphone.view;

import Util.JsonFileManager;
import ec.edu.espe.cellphone.model.CellPhone;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Andrés Espinosa
 */
public class CellPhoneApp {
    public static void main(String[] args) {
        
        int id;
        int option;
        String brand;
        String model;
        float price;
        boolean insert =true;
        Scanner scanner = new Scanner(System.in);
        
        ArrayList<CellPhone> cellPhones = new ArrayList<CellPhone>();
        cellPhones = JsonFileManager.ReadJson("cellPhones.json");
        for (CellPhone cellPhone : cellPhones)
            System.out.println("Your cellphones are: " + cellPhone);
            
        do{
            System.out.println("Enter the id-->");
            id = scanner.nextInt();
            
            System.out.println("Enter the brand-->");
            brand = scanner.nextLine();
            scanner.nextLine();
            
            System.out.println("Enter the model-->");
            model = scanner.nextLine();
                    
            System.out.println("Enter the price-->");
            price = scanner.nextFloat();
            
            CellPhone cellPhone = new CellPhone(id, brand, model, price, null);
            
            cellPhones.add(cellPhone);
            
            System.out.println("You want enter another Cellphone? :");
            System.out.println("1. : YES");
            System.out.println("2. : NO");
            option = scanner.nextInt();
            
            if(option == 2)
                insert =false;
            JsonFileManager.writeListToJson("cellPhones.json", cellPhones);
        }while( insert == true);
        
    }
    
}
