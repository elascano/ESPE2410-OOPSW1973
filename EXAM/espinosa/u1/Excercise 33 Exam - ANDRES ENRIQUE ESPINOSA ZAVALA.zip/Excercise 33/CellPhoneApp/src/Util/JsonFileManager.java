package Util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import ec.edu.espe.cellphone.model.CellPhone;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Andrés Espinosa
 */
public class JsonFileManager {
    
    public static <T> void writeListToJson(String filePath, List<T> list) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try (FileWriter writer = new FileWriter(filePath)) {
            gson.toJson(list, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static ArrayList<CellPhone> ReadJson(String filePath) {
        Gson gson = new Gson(); 
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) { 
            Type chickenListType = new TypeToken<List<CellPhone>>() {}.getType();
            return gson.fromJson(reader, chickenListType);
        } catch (IOException e) { e.printStackTrace();
        } return null;
    }
}
