package ec.edu.espe.model;

/**
 *
 * @author Klever Jami
 */
public class F {

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("F{");
        sb.append('}');
        return sb.toString();
    }

    
}
