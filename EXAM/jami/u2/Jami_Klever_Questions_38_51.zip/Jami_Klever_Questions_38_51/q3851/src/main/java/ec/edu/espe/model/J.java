package ec.edu.espe.model;
/**
 *
 * @author Klever Jami
 */
public class J {

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("J{");
        sb.append('}');
        return sb.toString();
    }
    
}
