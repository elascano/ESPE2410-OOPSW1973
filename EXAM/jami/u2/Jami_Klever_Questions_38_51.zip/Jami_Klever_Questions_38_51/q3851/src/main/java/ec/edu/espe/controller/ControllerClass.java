package ec.edu.espe.controller;
/**
 *
 * @author Klever Jami
 */

public class ControllerClass {
    
         
    public void executeLogic() {
        System.out.println("The logic the controlller an instance a object: A, B, C, D, E, F, G, H, J");
    }
}