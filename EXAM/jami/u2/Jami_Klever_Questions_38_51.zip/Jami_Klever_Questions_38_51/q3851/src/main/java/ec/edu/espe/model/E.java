package ec.edu.espe.model;

/**
 *
 * @author Klever Jami
 */
public class E {

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("E{");
        sb.append('}');
        return sb.toString();
    }

    
}
