package ec.edu.espe.model;

/**
 *
 * @author Klever Jami
 */
public interface H {

    public void m(J j) ;


    public J m();

}
