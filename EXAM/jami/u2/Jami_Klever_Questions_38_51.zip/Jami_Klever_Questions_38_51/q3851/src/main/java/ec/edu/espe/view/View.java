package ec.edu.espe.view;

/**
 *
 * @author Klever Jami
 */
public class View {
     public void displayInformation(String information) {
        System.out.println(information);
                        
    }
}
