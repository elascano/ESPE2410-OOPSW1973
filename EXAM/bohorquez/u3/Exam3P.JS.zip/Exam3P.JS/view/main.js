import { app, BrowserWindow, ipcMain } from "electron";
import path from "path";
import SortingController from "../controller/SortingController.js";

let mainWindow;

app.whenReady().then(() => {
    mainWindow = new BrowserWindow({
        width: 500,
        height: 400,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false
        }
    });

    mainWindow.loadFile("view/index.html");
});

ipcMain.on("sort-array", (event, input) => {
    const controller = new SortingController();
    controller.sortArray(input);
});
