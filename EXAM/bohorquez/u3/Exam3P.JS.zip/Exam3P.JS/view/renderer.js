const { ipcRenderer } = require("electron");

document.getElementById("sortButton").addEventListener("click", () => {
    const input = document.getElementById("numbersInput").value;
    if (!input.trim()) {
        alert("Please enter some numbers.");
        return;
    }

    ipcRenderer.send("sort-array", input);
    alert("Sorting started! Check the console for results.");
});
