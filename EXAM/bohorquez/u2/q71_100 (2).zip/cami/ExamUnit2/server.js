const express = require('express');
const path = require('path');
const cors = require('cors');
const ComputerController = require('./ec/edu/examunit2/controller/ComputerController.js');  

const app = express();
const port = 3000;

app.use(cors());
app.set('view engine', 'ejs'); 
app.set('views', path.join(__dirname, 'ec/edu/examunit2/view'));

// Serve static files
app.use(express.static(path.join(__dirname, 'ec/edu/examunit2/view')));

const computerController = new ComputerController();

app.get('/', async (req, res) => {
    try {
        const computers = await computerController.getAllComputers();
        res.render('FrmMenu', { computers });
    } catch (err) {
        console.error(err);
        res.status(500).send('Error al obtener los datos.');
    }
});

app.get('/computers', async (req, res) => {
    try {
        const computers = await computerController.getAllComputers();
        res.json(computers);
    } catch (err) {
        console.error(err);
        res.status(500).send('Error al obtener los datos.');
    }
});

app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
});