const MongoDBUtils = require('../../../../utils/MongoDBUtils');

class ComputerController {
    async getAllComputers() {
        const database = await MongoDBUtils.getDatabase();
        const collection = database.collection('Computers');
        const computers = await collection.find().toArray();
        return computers;
    }
}

module.exports = ComputerController;
