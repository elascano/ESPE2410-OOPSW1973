class Computer{
    #id;
    #name;
    #processorSpeed;
    #ramSize;

    Computer(id,name,processorSpeed,ramSize){
        this.#id = id;
        this.#name = name;
        this.processorSpeed = processorSpeed;
        this.#ramSize = ramSize;
    }

     // Getter y setter para #id
     getId() {
        return this.#id;
    }

    setId(id) {
        this.#id = id;
    }

    // Getter y setter para #name
    getName() {
        return this.#name;
    }

    setName(name) {
        this.#name = name;
    }

    // Getter y setter para #processorSpeed
    getProcessorSpeed() {
        return this.#processorSpeed;
    }

    setProcessorSpeed(processorSpeed) {
        this.#processorSpeed = processorSpeed;
    }

    // Getter y setter para #ramSize
    getRamSize() {
        return this.#ramSize;
    }

    setRamSize(ramSize) {
        this.#ramSize = ramSize;
    }

}

module.exports = Computer;