const tbody = document.querySelector('tbody');

async function loadComputers() {
    tbody.innerHTML = '';
    try {
        const response = await fetch('http://localhost:3000/computers');
        const computers = await response.json();
        computers.forEach(computer => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${computer._id}</td>
                <td>${computer.name}</td>
                <td>${computer.processorSpeed}</td>
                <td>${computer.ramSize}</td>
            `;
            tbody.appendChild(row);
        });
    } catch (err) {
        console.error('Error loading computers:', err);
    }
}

loadComputers();