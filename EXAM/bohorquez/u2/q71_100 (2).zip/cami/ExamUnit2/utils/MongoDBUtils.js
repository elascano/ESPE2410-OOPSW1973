const { MongoClient } = require('mongodb');

class MongoDBUtils {
    static DATABASE_NAME = "exam_unit_2";
    static uri = "mongodb+srv://camilabohorquez:camilabohorquez@cluster0.6u5fl.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
    static client = new MongoClient(MongoDBUtils.uri);
    static database = null;

    static async getDatabase() {
        if (!MongoDBUtils.database) {
            await MongoDBUtils.client.connect();
            MongoDBUtils.database = MongoDBUtils.client.db(MongoDBUtils.DATABASE_NAME);
        }
        return MongoDBUtils.database;
    }
}

module.exports = MongoDBUtils;