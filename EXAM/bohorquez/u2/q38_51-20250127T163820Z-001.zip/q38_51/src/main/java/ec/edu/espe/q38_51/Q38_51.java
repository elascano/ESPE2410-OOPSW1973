package ec.edu.espe.q38_51;
import ec.edu.espe.q38.model.*;
import static ec.edu.espe.q38.model.G.useJ;

/**
 *
 * @author Camila Bohorquez
 */
public class Q38_51 {
    public static void main(String[] args) {
        
        A a = new A(new A());
        B b = new B();
        C c = new C();
        D d = new D();
        E e = null;
        F f;
        G g;
        H h = null;
        J j = null;
        
        System.out.println("A --->" + a);
        System.out.println("B --->" + b);
        System.out.println("B --->" + c);
        System.out.println("B --->" + d);
        System.out.println("B --->" + e);
        System.out.println("B --->" + h);
        System.out.println("B --->" + j);
    }
}
