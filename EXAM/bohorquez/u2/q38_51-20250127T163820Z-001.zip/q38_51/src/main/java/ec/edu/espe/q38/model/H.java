package ec.edu.espe.q38.model;

/**
 *
 * @author Camila Bohorquez
 */
public interface H {
    
}
