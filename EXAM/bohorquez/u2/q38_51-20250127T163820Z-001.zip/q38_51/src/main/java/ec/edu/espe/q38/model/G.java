package ec.edu.espe.q38.model;

/**
 *
 * @author Camila Bohorquez
 */
public class G implements H {
    public static void useJ(J j){
        
    };
}
