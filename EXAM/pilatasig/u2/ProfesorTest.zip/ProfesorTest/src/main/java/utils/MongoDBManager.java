package utils;

import com.mongodb.client.*;
import org.bson.Document;
import ec.edu.espe.Q70_100.model.Profesor;
import java.util.Collection;


public class MongoDBManager {
    private static MongoClient mongoClient;
    private static MongoDatabase database;
    private static MongoCollection<Document> collection;

    public static void connect(String connectionString, String dbName) {
        mongoClient = MongoClients.create(connectionString);
        database = mongoClient.getDatabase(dbName);
        collection = database.getCollection("Profesors");
        
        if(collection==null){
            System.out.println("Error al inicializar la DataBase");
        }
        else{
            System.out.println("Conexión realizada");
        }
    }
    
   public static boolean add(String collectionName, Document profesorDocument) {
    MongoCollection<Document> collection = database.getCollection(collectionName);

    if (collection == null) {
        throw new IllegalStateException("MongoDB collection is not initialized.");
    }

    collection.insertOne(profesorDocument);
    return true;
}

    public static void close() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
}


    
