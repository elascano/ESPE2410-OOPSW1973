package ec.edu.espe.Q70_100.controller;

import org.bson.Document;
import utils.MongoDBManager;

/**
 *
 * @author David Pilatasig
 */
public class ProfesorController {
    public boolean add(String collectionName, Document profesor){
        boolean added= false;
        
        if(MongoDBManager.add(collectionName, profesor)){
            added= true;
        }
        return added;
    }
    
    public float paid(int hour, float paidForHour){
        float paid;
        paid= hour*paidForHour;
        return paid;
    }
        
}
