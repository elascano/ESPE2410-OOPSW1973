package ec.edu.espe.Q70_100.model;

import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author David Pilatasig
 */
public class Profesor {
     private String id;
    private String name;
    private int workinghours;
    private float paidForHour;
    private float paid;

    public Profesor(String id, String name, int workinghours, float paidForHour, float paid) {
        this.id = id;
        this.name = name;
        this.workinghours = workinghours;
        this.paidForHour = paidForHour;
        this.paid = paid;
    }

    public float getPaid() {
        return paid;
    }

    public void setPaid(float paid) {
        this.paid = paid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getWorkinghours() {
        return workinghours;
    }

    public void setWorkinghours(int workinghours) {
        this.workinghours = workinghours;
    }

    public float getPaidForHour() {
        return paidForHour;
    }

    public void setPaidForHour(float paidForHour) {
        this.paidForHour = paidForHour;
    }

    @Override
    public String toString() {
        return "Profesor{" + "id=" + id + ", name=" + name + ", workinghours=" + workinghours + ", paidForHour=" + paidForHour + ", paid=" + paid + '}';
    }
    
    
}
