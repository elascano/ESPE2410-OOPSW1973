import json

class Pencil:
    def __init__(self, id, brand, color, length):
        self.id = id
        self._brand = brand
        self._color = color
        self._length = length

    @property
    def brand(self):
        return self._brand

    @property
    def color(self):
        return self._color

    @property
    def length(self):
        return self._length

    @brand.setter
    def brand(self, new_brand):
        self._brand = new_brand

    @color.setter
    def color(self, new_color):
        self._color = new_color

    @length.setter
    def length(self, new_length):
        self._length = new_length


class ReadPencil:
    @staticmethod
    def read(filename):
        try:
            with open(filename, 'r') as file:
                pencil_data = json.load(file)
                return [Pencil(p['id'], p['_brand'], p['_color'], p['_length']) for p in pencil_data]
        except Exception as error:
            raise Exception(f"Error reading {filename}: {error}")


class SavePencil:
    @staticmethod
    def save(pencils, filename):
        if not isinstance(pencils, list) or not all(isinstance(p, Pencil) for p in pencils):
            raise Exception("The object to save is not an array of Pencil instances.")
        json_data = json.dumps([p.__dict__ for p in pencils])
        with open(filename, 'w') as file:
            file.write(json_data)
        print(f"Pencils saved to {filename}")


def ask_question(query):
    return input(query)


def main():
    pencils = []
    id = 1

    while True:
        brand = ask_question(f"Enter brand for pencil {id}: ")
        color = ask_question(f"Enter color for pencil {id}: ")
        length = ask_question(f"Enter length for pencil {id}: ")

        pencils.append(Pencil(id, brand, color, float(length)))

        another = ask_question('Do you want to add another pencil? (yes/no): ')
        if another.lower() != 'yes':
            break

        id += 1

    filename = 'pencil.json'
    SavePencil.save(pencils, filename)

    read_pencils = ReadPencil.read(filename)

    print("Read Pencils:", read_pencils)

if __name__ == "__main__":
    main()
