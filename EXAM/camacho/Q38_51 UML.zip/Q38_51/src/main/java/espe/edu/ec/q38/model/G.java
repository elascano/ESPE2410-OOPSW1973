package espe.edu.ec.q38.model;

/**
 *
 * @author Mateo
 */
public class G implements H{//1
    
}
