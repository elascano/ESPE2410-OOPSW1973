/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package espe.edu.ec.q38.view;

/**
 *
 * @author G400
 */
public class Q38 {

    public static void main(String[] args) {
        System.out.println("Excerise 38-51");
    }
}
