package espe.edu.ec.q38.model;
import espe.edu.ec.q38.model.G;

/**
 *
 * @author Mateo
 */
public interface H {
}
