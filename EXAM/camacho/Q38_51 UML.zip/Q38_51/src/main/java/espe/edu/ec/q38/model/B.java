package espe.edu.ec.q38.model;
import java.util.ArrayList;

/**
 *
 * @author Mateo
 */
public class B extends A{
    
    private ArrayList<H> r = new ArrayList<>(1);

    public B(ArrayList<A> as) {
        super(as);
    }

    @Override
    public String toString() {
        return "B{" + "r= " + r + '}';
    }
    
    /**
     * @return the h
     */
    public ArrayList<H> getH() {
        return r;
    }

    /**
     * @param h the h to set
     */
    public void setH(ArrayList<H> h) {
        this.r = r;
    }
    
    
}
