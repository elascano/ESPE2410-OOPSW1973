package ec.edu.espe.strategy.model;

/**
 *
 * @author Klever Jami
 */
public interface SortingStrategy {

    int[] sort(int data[]);
}
