/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ec.edu.espe.appcondomanagement.view;

/**
 *
 * @author Klever Jami
 */
public class AppCondoManagement {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
