package ec.edu.espe.abstractfactory.model;

/**
 *
 * @author Klever Jami
 */
public abstract class Menu {

    protected String caption;

    public abstract void paint();
}
