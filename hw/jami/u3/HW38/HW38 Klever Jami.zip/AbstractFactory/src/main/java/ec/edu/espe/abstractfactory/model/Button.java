package ec.edu.espe.abstractfactory.model;

/**
 *
 * @author Klever Jami
 */
public abstract class Button {

    protected String caption;

    public abstract void paint();
}
