package ec.edu.espe.composite.model;

/**
 *
 * @author Klever Jami
 */
public class Manager extends Supervisor {

    public Manager(String aName) {
        name = aName;
        title = "Manager";
    }
}
