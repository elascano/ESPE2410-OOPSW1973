package ec.edu.espe.composite.model;

/**
 *
 * @author Klever Jami
 */
public class Clerk extends Employee {

    public Clerk(String aName) {
        name = aName;
        title = "Clerk";
    }
}
