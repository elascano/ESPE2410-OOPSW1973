package ec.edu.espe.template.view;

import ec.edu.espe.template.controller.BeverageController;

/**
 *
 * @author Klever Jami
 */
public class BeverageTest {

    public static void main(String[] args) {
        BeverageController controller = new BeverageController();
        controller.prepareBeverages();
    }
}
