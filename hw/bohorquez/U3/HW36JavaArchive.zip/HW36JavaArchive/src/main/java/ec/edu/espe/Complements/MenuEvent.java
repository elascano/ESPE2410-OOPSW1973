
package ec.edu.espe.Complements;

/**
 *
 * @author Dennis Paucar
 */
public interface MenuEvent {
    public void selected(int index, int subIndex);
}
