package ec.edu.espe.model;

/**
 *
 * @author Brandon Pazmino
 */
public class Notification {
    
}
