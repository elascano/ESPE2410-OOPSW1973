const express = require("express");
const Home = require("../model/Home");

const router = express.Router();


const getHome = async (req, res, next) => {
    let home;
    const { id } = req.params;

    try {
        home = await Home.findOne({ id }); 
        if (!home) {
            return res.status(404).json({ message: "The book was not found" });
        }
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }

    req.home = home; 
    next();
};


router.get("/", async (req, res) => {
    try {
        const homes = await Home.find();
        if (homes.length === 0) {
            return res.status(204).json({});
        }
        res.json(homes);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});





router.post("/", async (req, res) => {
    const { id, style, author, seller,  price } = req.body;

    if (!(id && style && author && seller && price)) {
        return res.status(400).json({
            message: "You must submit the id, title, author, genre, and year of publication"
        });
    }


    const home = new Home({ id, style, author, seller, price });

    try {
        const newHome = await home.save(); 
        res.status(201).json(newHome);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


router.get("/:id", getHome, (req, res) => {
    res.json(req.home);
});


router.put("/:id", getHome, async (req, res) => {
    try {
        const home = req.home;
        home.title = req.body.id || home.id;
        home.style = req.body.style || home.style;
        home.seller = req.body.genre || home.seller;
        home.price = req.body.price || home.price; 

        const updatedHome = await home.save();
        res.json(updatedHome);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});


router.delete("/:id", getHome, async (req, res) => {
    try {
        await req.home.deleteOne(); 
        res.json({ message: `The book "${req.home.id}" was successfully eliminated` });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
