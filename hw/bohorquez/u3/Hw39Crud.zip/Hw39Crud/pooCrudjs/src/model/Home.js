const mongoose = require("mongoose")

const Home = new mongoose.Schema(
    {
        id: String,
        style: String,
        author: String,
        seller: String,
        price: Number
        

    },
    {
        collection: "homes"
    }
)

module.exports = mongoose.model("Home",Home)