const express = require("express");
const moongose = require("mongoose");
const cors = require("cors")
const bodyParser = require("body-parser")
const routes = require("./controller/Routes");




const app = express()
const port = 3002

app.use(cors())

app.use(bodyParser.json())

moongose.connect("mongodb+srv://camilabohorquez:camilabohorquez@cluster0.6u5fl.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",{dbName:"Home"})
db = moongose.connection

app.use("/homes",routes)

app.listen(port,()=>{
    console.log(`Listening on port ${port}`)
})
