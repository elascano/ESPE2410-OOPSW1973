const API_URL = "http://localhost:3002/books"; 

document.getElementById("updateForm").addEventListener("submit", updateBook);

async function updateBook(event) {
    event.preventDefault();

    const id = document.getElementById("updateId").value;
    const title = document.getElementById("updateStyle").value;
    const author = document.getElementById("updateAuthor").value;
    const genre = document.getElementById("updateSeller").value;
    const year = document.getElementById("updatePrice").value;
    const message = document.getElementById("updateMessage");

    const updatedHome = { id, style, author, seller, price };

    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(updatedHome),
        });

        if (!response.ok) throw new Error("Failed to update book");

        message.textContent = "Home updated successfully!";
        message.style.color = "green";
        document.getElementById("updateForm").reset();
    } catch (error) {
        message.textContent = "Error: " + error.message;
        message.style.color = "red";
    }

}