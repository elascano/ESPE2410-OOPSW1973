const API_URL = "http://localhost:3002/homes";

document.addEventListener("DOMContentLoaded", fetchHomes);

async function fetchHomes() {
    try {
        const response = await fetch(API_URL);
        if (!response.ok) throw new Error(`Error ${response.status}: No se pudo obtener los datos.`);
        
        const text = await response.text();
        if (!text) throw new Error("La respuesta está vacía.");
        
        const homes = JSON.parse(text);
        const tableBody = document.getElementById("homeTable");
        
        if (!tableBody) {
            console.error("Error: No se encontró el elemento con ID 'homeTable'");
            return;
        }

        tableBody.innerHTML = ""; 

        homes.forEach(home => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${home.id}</td>
                <td>${home.style || "N/A"}</td>
                <td>${home.author || "N/A"}</td>
                <td>${home.seller || "N/A"}</td>
                <td>${home.price ? `$${home.price.toFixed(2)}` : "N/A"}</td>
            `;
            tableBody.appendChild(row);
        });
    } catch (error) {
        console.error("Error al obtener las casas:", error.message);
    }
}
