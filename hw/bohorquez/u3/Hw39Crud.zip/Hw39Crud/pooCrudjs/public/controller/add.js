const API_URL = "http://localhost:3002/homes"; 

document.getElementById("addForm").addEventListener("submit", function(event) {
    event.preventDefault(); 
    addHome(event);
});

async function addHome(event) {
    event.preventDefault();

    const id = document.getElementById("id").value;
    const style = document.getElementById("style").value;
    const author = document.getElementById("author").value;
    const seller = document.getElementById("seller").value;
    const price = document.getElementById("price").value;
    const message = document.getElementById("message");

    const home = { id, style, author, seller, price };

    try {
        const response = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(home),
        });

        if (!response.ok) throw new Error("Failed to add home");

        message.textContent = "Home added successfully!";
        message.style.color = "green";
        document.getElementById("addForm").reset();
    } catch (error) {
        message.textContent = "Error: " + error.message;
        message.style.color = "red";
    }
}