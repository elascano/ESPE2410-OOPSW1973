const API_URL = "http://localhost:3002/homes";
document.getElementById("searchForm").addEventListener("submit", searchBook);

async function searchBook(event) {
    event.preventDefault();

    const id = document.getElementById("searchId").value;
    const message = document.getElementById("searchMessage");
    const result = document.getElementById("searchResult");

    try {
        const response = await fetch(`${API_URL}/${id}`);
        if (!response.ok) throw new Error("Home not found");

        const home = await response.json();
        result.innerHTML = `
            <p><strong>id:</strong> ${home.id}</p>
            <p><strong>Style:</strong> ${home.style}</p>
            <p><strong>Author:</strong> ${home.author}</p>
            <p><strong>Seller:</strong> ${home.seller}</p>
            <p><strong>Price:</strong> ${home.price}</p>
        `;
        message.textContent = "";
    } catch (error) {
        message.textContent = "Error: " + error.message;
        message.style.color = "red";
        result.innerHTML = "";
    }
}